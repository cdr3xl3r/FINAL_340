Select * 
From Vehicle V
Join Inventory I ON V.VEH_NUM = I.VEH_NUM
